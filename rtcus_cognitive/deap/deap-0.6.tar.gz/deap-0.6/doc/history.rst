=======
History
=======

.. automodule:: eap.history
   
.. autoclass:: eap.history.History
   
   .. automethod:: eap.history.History.populate
   
   .. automethod:: eap.history.History.update(individual[, ...])
   
   .. automethod:: eap.history.History.decorator