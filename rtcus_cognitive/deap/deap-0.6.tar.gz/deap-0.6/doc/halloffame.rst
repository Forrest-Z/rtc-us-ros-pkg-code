============
Hall of Fame
============

.. automodule:: eap.halloffame

.. autoclass:: eap.halloffame.HallOfFame

   .. automethod:: eap.halloffame.HallOfFame.update
   
   .. automethod:: eap.halloffame.HallOfFame.insert
   
   .. automethod:: eap.halloffame.HallOfFame.remove
   
   .. automethod:: eap.halloffame.HallOfFame.clear

.. autoclass:: eap.halloffame.ParetoFront([similar])

   .. automethod:: eap.halloffame.ParetoFront.update