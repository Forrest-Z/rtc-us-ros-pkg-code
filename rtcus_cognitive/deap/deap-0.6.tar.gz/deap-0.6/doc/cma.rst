Covariance Matrix Adaptation Evolution Strategy
===============================================

.. autofunction:: eap.cma.esCMA(toolbox, population, sigma, ngen[, halloffame, **kargs])

.. autoclass:: eap.cma.CMAStrategy(population, sigma[, params])
   :members: