=========
Milestone
=========

.. automodule:: eap.milestone

.. autoclass:: eap.milestone.Milestone([yaml,object[, ...]])
   
   .. automethod:: eap.milestone.Milestone.dump(prefix)
   
   .. automethod:: eap.milestone.Milestone.load(filename)
   
   .. automethod:: eap.milestone.Milestone.add(object[, ...])
   
   .. automethod:: eap.milestone.Milestone.remove(object[, ...])